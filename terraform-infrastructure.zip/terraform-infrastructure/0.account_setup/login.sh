gcloud auth application-default login


sleep 5
gcloud auth  login

#gcloud config set project terraform-project-akhasa1